#include <stdio.h>
#include <stdlib.h>
#include "trabalho.h"

void exibirMenu() {
    printf("\n=== Sistema de Simulação do RU ===\n");
    printf("1. Inicializar Sistema\n");
    printf("2. Rodar Simulação\n");
    printf("3. Gerar Relatórios\n");
	printf("4. ver folha de ponto\n");
    printf("5. Sair\n");
    printf("Escolha uma opção: ");
}

int main() {
    int opcao,senha,tentativas = 0;
    do {
        exibirMenu();
        scanf("%d", &opcao);
        switch (opcao) {
            case 1:
                inicializar();
                printf("Sistema inicializado com sucesso!\n Regras: Ver folha de ponto somente para gestor caso erre 3 vezes a senha sistema vai ser bloqueado (senha para teste : 2024)..");
                break;
            case 2:
                simular();
                printf("Simulação concluída!\n");
                break;
            case 3:
                gerarRelatorios();
                break;
            case 4:
				printf("Senha:");
				scanf("%d",&senha);
				if(senha == 2024){
					printf("senha correta");
					Ponto();
					printf("Todos esses dados estão armazenados em .txt");
					break;
				}
				else{
				tentativas ++;
				exibirMenu();
				if (tentativas = 3) {
					printf("bloqueando\n");
					printf("Apagando banco de dados caso tente sair da tela de bloqueio");
				}
			}
			case 5:
                printf("Saindo do sistema...\n");
                break;
            default:
                printf("Opção inválida! Tente novamente.\n");
        }
    } while (opcao != 5);
    return 0;
}
